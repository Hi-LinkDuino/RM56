﻿
V1.6
0. Usage:
  a. Open audio tool after playing music. If connection lost, you should restart this tool.  
  b. You can click "preview" button to see EQs curves. Note: Curves ignore left gain and right gain.
  c. Left gain and right gain are used to normalize EQs total gain
  d. If you want to save EQs parameters, You can click "preview" button.
  
1. Modifaction:
  a. Add layout to solve some display issues.
  b. Add audition result status
  c. Try three times when translate data failed

2. BUG list:
  a. This version can not ping chip, then disconnect sometimes.
  b. Chip reply zeros values, PC tries three times.